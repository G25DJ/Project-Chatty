
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { GeneratedAsset } from '../types';

interface CreationStudioProps {
  onClose: () => void;
  onAssetGenerated: (asset: GeneratedAsset) => void;
  themePrimary: string;
}

const CreationStudio: React.FC<CreationStudioProps> = ({ onClose, onAssetGenerated, themePrimary }) => {
  const [activeTab, setActiveTab] = useState<'image' | 'video'>('image');
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [quality, setQuality] = useState<'flash' | 'pro'>('flash');

  const checkApiKey = async () => {
    // Only mandatory for Pro/Veo models
    const needsPro = quality === 'pro' || activeTab === 'video';
    if (needsPro && window.aistudio) {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      if (!hasKey) {
        await window.aistudio.openSelectKey();
      }
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    setStatusMessage('Initializing neural link...');

    try {
      await checkApiKey();
      // Guidelines: Create a new GoogleGenAI instance right before making an API call 
      // to ensure it always uses the most up-to-date API key from the dialog.
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

      if (activeTab === 'image') {
        setStatusMessage('Synthesizing latent pixels...');
        const model = quality === 'flash' ? 'gemini-2.5-flash-image' : 'gemini-3-pro-image-preview';
        const response = await ai.models.generateContent({
          model,
          contents: { parts: [{ text: prompt }] },
          config: { imageConfig: { aspectRatio: "1:1" } }
        });

        const part = response.candidates[0].content.parts.find(p => p.inlineData);
        if (part?.inlineData) {
          const url = `data:image/png;base64,${part.inlineData.data}`;
          onAssetGenerated({
            id: Math.random().toString(36).substr(2, 9),
            type: 'image',
            url,
            prompt,
            timestamp: new Date()
          });
        }
      } else {
        setStatusMessage('Compiling motion vectors (this may take 1-2 mins)...');
        let operation = await ai.models.generateVideos({
          model: 'veo-3.1-fast-generate-preview',
          prompt,
          config: { numberOfVideos: 1, resolution: '720p', aspectRatio: '16:9' }
        });

        while (!operation.done) {
          setStatusMessage(`Rendering sequence... [${new Date().toLocaleTimeString()}]`);
          await new Promise(resolve => setTimeout(resolve, 10000));
          operation = await ai.operations.getVideosOperation({ operation: operation });
        }

        const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (downloadLink) {
          const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
          const blob = await videoResponse.blob();
          const url = URL.createObjectURL(blob);
          onAssetGenerated({
            id: Math.random().toString(36).substr(2, 9),
            type: 'video',
            url,
            prompt,
            timestamp: new Date()
          });
        }
      }
    } catch (err: any) {
      console.error('Generation Error:', err);
      const errorMsg = err.message || JSON.stringify(err);
      
      // Guidelines: If the request fails with "Requested entity was not found.", 
      // reset key selection state and prompt user to select a key again.
      if (errorMsg.includes("Requested entity was not found")) {
        setStatusMessage('Model access restricted. Updating authorization...');
        if (window.aistudio) {
          await window.aistudio.openSelectKey();
        }
      } else {
        setStatusMessage(`Error: ${errorMsg}`);
      }
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6 animate-fade-in">
      <div className="w-full max-w-4xl bg-[#05050f] border border-white/10 rounded-[3rem] overflow-hidden flex flex-col h-[80vh]">
        <div className="flex items-center justify-between p-8 border-b border-white/5">
          <div className="flex gap-4">
            <button 
              onClick={() => setActiveTab('image')} 
              className={`px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'image' ? `bg-${themePrimary} text-white` : 'text-gray-500 hover:text-white'}`}
            >
              Visual Forge
            </button>
            <button 
              onClick={() => setActiveTab('video')} 
              className={`px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'video' ? `bg-purple-600 text-white` : 'text-gray-500 hover:text-white'}`}
            >
              Motion Engine
            </button>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-white"><i className="fas fa-times text-xl"></i></button>
        </div>

        <div className="flex-1 overflow-y-auto p-10 space-y-8">
          <div className="space-y-4">
            <label className="text-[10px] font-black text-gray-600 uppercase tracking-widest">Neural Prompt</label>
            <textarea 
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={activeTab === 'image' ? "Describe the image in detail..." : "Describe the cinematic motion..."}
              className="w-full h-32 bg-white/5 border border-white/10 rounded-2xl p-6 text-white font-medium focus:outline-none focus:border-blue-500/50 resize-none transition-all"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex flex-col gap-2">
              {activeTab === 'image' && (
                <div className="flex bg-white/5 rounded-xl p-1 w-fit">
                  <button 
                    onClick={() => setQuality('flash')} 
                    className={`px-4 py-2 rounded-lg text-[9px] font-black uppercase tracking-tighter ${quality === 'flash' ? 'bg-white/10 text-white' : 'text-gray-500'}`}
                  >
                    Draft
                  </button>
                  <button 
                    onClick={() => setQuality('pro')} 
                    className={`px-4 py-2 rounded-lg text-[9px] font-black uppercase tracking-tighter ${quality === 'pro' ? 'bg-blue-500/20 text-blue-400' : 'text-gray-500'}`}
                  >
                    High Fidelity
                  </button>
                </div>
              )}
              <a 
                href="https://ai.google.dev/gemini-api/docs/billing" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[8px] text-gray-500 hover:text-blue-400 font-black uppercase tracking-widest transition-colors"
              >
                <i className="fas fa-info-circle mr-1"></i> Billing Requirements Info
              </a>
            </div>
            
            <button 
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className={`px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center gap-3 transition-all ${isGenerating ? 'bg-white/10 text-gray-500' : `bg-white text-black hover:scale-105 active:scale-95`}`}
            >
              {isGenerating ? <i className="fas fa-circle-notch fa-spin"></i> : <i className="fas fa-bolt"></i>}
              {isGenerating ? 'Synthesizing...' : 'Ignite Forge'}
            </button>
          </div>

          {isGenerating && (
            <div className="p-8 border border-white/5 bg-white/[0.02] rounded-[2rem] animate-pulse">
              <div className="flex items-center gap-4 text-blue-400 font-mono text-[10px] uppercase tracking-[0.2em]">
                <div className="w-2 h-2 rounded-full bg-blue-500 animate-ping"></div>
                {statusMessage}
              </div>
              <div className="mt-4 h-1 w-full bg-white/5 rounded-full overflow-hidden">
                <div className={`h-full bg-${themePrimary} animate-[scan_2s_infinite]`}></div>
              </div>
            </div>
          )}
        </div>

        <div className="p-8 bg-black/40 border-t border-white/5 text-center">
          <p className="text-[9px] text-gray-600 font-black uppercase tracking-[0.5em]">
            Powered by {activeTab === 'video' ? 'VEO 3.1' : quality === 'pro' ? 'Gemini 3 Pro' : 'Gemini 2.5 Flash'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default CreationStudio;
